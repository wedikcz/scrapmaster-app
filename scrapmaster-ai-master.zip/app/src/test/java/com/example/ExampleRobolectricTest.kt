package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ThemeMode
import com.example.data.local.ThemePreferenceManager
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ScrapMaster AI", appName)
  }

  @Test
  fun `theme toggle persists across sessions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val themeManager = ThemePreferenceManager.getInstance(context)

    themeManager.setThemeMode(ThemeMode.DARK)
    assertEquals(ThemeMode.DARK, themeManager.themeMode.value)

    themeManager.toggleTheme()
    assertEquals(ThemeMode.LIGHT, themeManager.themeMode.value)

    themeManager.toggleTheme()
    assertEquals(ThemeMode.DARK, themeManager.themeMode.value)
  }
}
