package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CyberCard
import com.example.ui.components.IndustrialBadge
import com.example.ui.theme.LocalScrapMasterColors
import com.example.ui.theme.TechMonoFamily
import com.example.viewmodel.AssistantMessage
import com.example.viewmodel.WorkshopViewModel

@Composable
fun AssistantScreen(
  viewModel: WorkshopViewModel,
  modifier: Modifier = Modifier
) {
  val colors = LocalScrapMasterColors.current

  val messages by viewModel.assistantMessages.collectAsStateWithLifecycle()
  val isSearching by viewModel.isAssistantSearching.collectAsStateWithLifecycle()
  val datasheets by viewModel.datasheets.collectAsStateWithLifecycle()

  var inputQuery by remember { mutableStateOf("") }

  val promptShortcuts = listOf(
    "Jak otestovat MOSFET multimetrem?",
    "Náhrada za LM7805 bez přehřívání?",
    "Zapojení NE555 astabilní klopný obvod",
    "Bezpečné vybití VN kondenzátoru v SMPS",
    "Diagnostika čipu ESP32 z e-waste"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp)
  ) {
    Spacer(modifier = Modifier.height(4.dp))

    // Header & RAG Status
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "RAG DATASHEET AI ASISTENT",
          fontFamily = TechMonoFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp,
          color = colors.textPrimary,
          letterSpacing = 0.5.sp
        )
        Text(
          text = "Lokální sémantické vyhledávání s ověřitelnými citacemi",
          fontFamily = TechMonoFamily,
          fontSize = 11.sp,
          color = colors.textMuted
        )
      }

      IndustrialBadge(
        text = "${datasheets.size} DOKUMENTŮ",
        color = colors.primaryAccent,
        icon = Icons.AutoMirrored.Filled.MenuBook
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Indexed Documents & Schematics Carousel
    Text(
      text = "INDEXOVANÁ SCHÉMATA & DATASHEETY V RAG BÁZI:",
      fontFamily = TechMonoFamily,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = colors.secondaryAccent
    )
    Spacer(modifier = Modifier.height(4.dp))
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(datasheets) { doc ->
        val isSchematic = doc.category == "SCHEMATIC"
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(colors.surfaceVariant)
            .border(
              0.8.dp,
              if (isSchematic) colors.primaryAccent else colors.cardBorder,
              RoundedCornerShape(8.dp)
            )
            .clickable {
              val q = "Analyzuj schéma a zapojení: ${doc.title}"
              inputQuery = q
              viewModel.askAssistant(q)
              inputQuery = ""
            }
            .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.MenuBook,
              contentDescription = null,
              tint = if (isSchematic) colors.primaryAccent else colors.secondaryAccent,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = doc.fileName,
              fontFamily = TechMonoFamily,
              fontSize = 10.sp,
              fontWeight = if (isSchematic) FontWeight.Bold else FontWeight.Normal,
              color = if (isSchematic) colors.primaryAccent else colors.textPrimary
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Prompt Shortcut Chips
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(promptShortcuts) { shortcut ->
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(colors.surfaceVariant)
            .border(0.8.dp, colors.primaryAccent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .clickable {
              inputQuery = shortcut
              viewModel.askAssistant(shortcut)
              inputQuery = ""
            }
            .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Text(
            text = shortcut,
            fontFamily = TechMonoFamily,
            fontSize = 10.5.sp,
            color = colors.textPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Chat Stream
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(messages, key = { it.id }) { msg ->
        ChatMessageItem(message = msg)
      }

      if (isSearching) {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              color = colors.primaryAccent,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Prohledávám lokální datasheety a páruji citace...",
              fontFamily = TechMonoFamily,
              fontSize = 11.sp,
              color = colors.primaryAccent
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Input Bar
    CyberCard {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = inputQuery,
          onValueChange = { inputQuery = it },
          placeholder = {
            Text(
              text = "Položte technický dotaz k datasheetu...",
              fontFamily = TechMonoFamily,
              fontSize = 12.sp,
              color = colors.textMuted
            )
          },
          modifier = Modifier
            .weight(1f)
            .testTag("assistant_input_field"),
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.primaryAccent,
            unfocusedBorderColor = colors.cardBorder,
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary,
            focusedContainerColor = colors.surfaceVariant,
            unfocusedContainerColor = colors.surfaceVariant
          ),
          singleLine = true
        )

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(colors.primaryAccent)
            .clickable {
              if (inputQuery.isNotBlank()) {
                viewModel.askAssistant(inputQuery)
                inputQuery = ""
              }
            }
            .testTag("assistant_send_btn"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Odeslat",
            tint = if (colors.isDark) colors.background else colors.surface,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(80.dp))
  }
}

@Composable
private fun ChatMessageItem(message: AssistantMessage) {
  val colors = LocalScrapMasterColors.current

  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start
  ) {
    Box(
      modifier = Modifier
        .clip(
          RoundedCornerShape(
            topStart = 12.dp,
            topEnd = 12.dp,
            bottomStart = if (message.isUser) 12.dp else 2.dp,
            bottomEnd = if (message.isUser) 2.dp else 12.dp
          )
        )
        .background(
          if (message.isUser) colors.primaryAccent.copy(alpha = if (colors.isDark) 0.22f else 0.16f)
          else colors.surfaceVariant
        )
        .border(
          width = 0.8.dp,
          color = if (message.isUser) colors.primaryAccent.copy(alpha = 0.6f) else colors.cardBorder,
          shape = RoundedCornerShape(12.dp)
        )
        .padding(12.dp)
    ) {
      Column {
        Text(
          text = message.text,
          fontFamily = TechMonoFamily,
          fontSize = 12.sp,
          color = colors.textPrimary,
          lineHeight = 17.sp
        )

        // Exact Citations List
        if (message.citations.isNotEmpty()) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "POVINNÉ CITACE ZDROJŮ:",
            fontFamily = TechMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            color = colors.secondaryAccent
          )
          Spacer(modifier = Modifier.height(2.dp))
          message.citations.forEach { citation ->
            Text(
              text = citation,
              fontFamily = TechMonoFamily,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              color = colors.primaryAccent
            )
          }
        }
      }
    }
  }
}
