package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.PinoutEntity
import com.example.ui.components.CyberCard
import com.example.ui.components.IndustrialBadge
import com.example.ui.components.NeonButton
import com.example.ui.components.PinoutVisualizer
import com.example.ui.theme.LocalScrapMasterColors
import com.example.ui.theme.TechMonoFamily
import com.example.viewmodel.WorkshopViewModel

@Composable
fun PinoutsScreen(
  viewModel: WorkshopViewModel,
  modifier: Modifier = Modifier
) {
  val colors = LocalScrapMasterColors.current
  val pinouts by viewModel.pinouts.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var showAddDialog by remember { mutableStateOf(false) }

  val filteredPinouts = pinouts.filter { p ->
    searchQuery.isBlank() ||
        p.componentModel.contains(searchQuery, ignoreCase = true) ||
        p.description.contains(searchQuery, ignoreCase = true) ||
        p.packageType.contains(searchQuery, ignoreCase = true)
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header
    item {
      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "KATALOG PINOUTŮ",
            fontFamily = TechMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = colors.textPrimary,
            letterSpacing = 0.5.sp
          )
          Text(
            text = "${pinouts.size} modelů čipů • Interaktivní mapování pinů",
            fontFamily = TechMonoFamily,
            fontSize = 11.sp,
            color = colors.textMuted
          )
        }

        NeonButton(
          text = "+ Vlastní",
          onClick = { showAddDialog = true },
          icon = Icons.Default.Add,
          testTag = "pinouts_add_btn"
        )
      }
    }

    // Search bar
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = {
          Text(
            text = "Hledat model IC (NE555, LM7805, ESP32, IRFZ44N)...",
            fontFamily = TechMonoFamily,
            fontSize = 12.sp,
            color = colors.textMuted
          )
        },
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = colors.primaryAccent
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("pinouts_search_field"),
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = colors.primaryAccent,
          unfocusedBorderColor = colors.cardBorder,
          focusedTextColor = colors.textPrimary,
          unfocusedTextColor = colors.textPrimary,
          focusedContainerColor = colors.surfaceVariant,
          unfocusedContainerColor = colors.surfaceVariant
        ),
        singleLine = true
      )
    }

    // Pinout cards with interactive visualizer
    if (filteredPinouts.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Žádný pinout neodpovídá zadanému hledání.",
            fontFamily = TechMonoFamily,
            fontSize = 12.sp,
            color = colors.textMuted
          )
        }
      }
    } else {
      items(filteredPinouts, key = { it.id }) { pinout ->
        CyberCard {
          Column(modifier = Modifier.padding(14.dp)) {
            PinoutVisualizer(pinout = pinout)

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = pinout.description,
              fontFamily = TechMonoFamily,
              fontSize = 11.5.sp,
              color = colors.textSecondary
            )

            if (pinout.typicalApp.isNotBlank()) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Typické použití: ${pinout.typicalApp}",
                fontFamily = TechMonoFamily,
                fontSize = 10.5.sp,
                color = colors.textMuted
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(80.dp))
    }
  }

  if (showAddDialog) {
    AddPinoutDialog(
      onDismiss = { showAddDialog = false },
      onConfirm = { model, pkg, desc, count, volt, pinsJson ->
        viewModel.addNewPinout(model, pkg, desc, count, volt, pinsJson)
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun AddPinoutDialog(
  onDismiss: () -> Unit,
  onConfirm: (String, String, String, Int, String, String) -> Unit
) {
  val colors = LocalScrapMasterColors.current

  var model by remember { mutableStateOf("") }
  var packageType by remember { mutableStateOf("DIP-8") }
  var description by remember { mutableStateOf("") }
  var pinCount by remember { mutableStateOf("8") }
  var voltage by remember { mutableStateOf("5V - 12V") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "PŘIDAT VLASTNÍ PINOUT",
        fontFamily = TechMonoFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = colors.primaryAccent
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = model,
          onValueChange = { model = it },
          label = { Text("Model IC (např. LM358)", fontFamily = TechMonoFamily, fontSize = 11.sp) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = packageType,
            onValueChange = { packageType = it },
            label = { Text("Pouzdro", fontFamily = TechMonoFamily, fontSize = 11.sp) },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = pinCount,
            onValueChange = { pinCount = it },
            label = { Text("Počet pinů", fontFamily = TechMonoFamily, fontSize = 11.sp) },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }
        OutlinedTextField(
          value = voltage,
          onValueChange = { voltage = it },
          label = { Text("Napájecí napětí", fontFamily = TechMonoFamily, fontSize = 11.sp) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Popis obvodu", fontFamily = TechMonoFamily, fontSize = 11.sp) },
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      TextButton(
        onClick = {
          if (model.isNotBlank()) {
            val count = pinCount.toIntOrNull() ?: 8
            val pinsBuilder = StringBuilder("[")
            for (i in 1..count) {
              pinsBuilder.append("{\"pin\":$i,\"label\":\"P$i\",\"type\":\"IO\",\"desc\":\"Pin $i\"}")
              if (i < count) pinsBuilder.append(",")
            }
            pinsBuilder.append("]")

            onConfirm(model, packageType, description, count, voltage, pinsBuilder.toString())
          }
        }
      ) {
        Text("ULOŽIT", fontFamily = TechMonoFamily, fontWeight = FontWeight.Bold, color = colors.primaryAccent)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("ZRUŠIT", fontFamily = TechMonoFamily, color = colors.textMuted)
      }
    },
    containerColor = colors.surface,
    shape = RoundedCornerShape(14.dp)
  )
}
